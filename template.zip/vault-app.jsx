/* vault-app.jsx — entry */

const VAULT_TWEAKS = /*EDITMODE-BEGIN*/{
  "theme": "paper",
  "accent": "#A8462E"
}/*EDITMODE-END*/;

const VAULT_THEMES = {
  paper: { bg:"#F4F0E6", paper:"#ECE5D2", fg:"#1A1714", muted:"#857C68", line:"#D6CCB6" },
  ink:   { bg:"#0E0E0C", paper:"#16140F", fg:"#F0EADA", muted:"#7E7763", line:"#26241F" },
  bone:  { bg:"#EFEAE0", paper:"#E5DFD2", fg:"#0E0E0E", muted:"#6E6A60", line:"#D5CDB9" },
};

const VAULT_ACCENTS = ["#A8462E","#1A1714","#2235FF","#4F8C5B","#C58B2A"];

function VaultApp(){
  const [t, setTweak] = useTweaks(VAULT_TWEAKS);
  React.useEffect(()=>{
    const r = document.documentElement;
    const theme = VAULT_THEMES[t.theme] || VAULT_THEMES.paper;
    r.style.setProperty("--vt-bg", theme.bg);
    r.style.setProperty("--vt-paper", theme.paper);
    r.style.setProperty("--vt-fg", theme.fg);
    r.style.setProperty("--vt-muted", theme.muted);
    r.style.setProperty("--vt-line", theme.line);
    r.style.setProperty("--vt-accent", t.accent);
    r.dataset.theme = t.theme === "ink" ? "ink" : "light";
  },[t.theme, t.accent]);

  return (
    <>
      <VaultPortfolio />
      <TweaksPanel title="Vault tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Paper" value={t.theme} options={["paper","bone","ink"]} onChange={(v)=>setTweak("theme", v)} />
        <TweakColor label="Accent" value={t.accent} options={VAULT_ACCENTS} onChange={(v)=>setTweak("accent", v)} />
        <TweakSection label="About" />
        <div style={{ fontSize:11, color:"rgba(41,38,27,.55)", lineHeight:1.5 }}>
          <strong style={{ color:"rgba(41,38,27,.85)" }}>VAULT</strong> — sans archive theme.<br/>
          Anton · Manrope · JetBrains Mono. <br/>
          Categories → Folders → Plates.
        </div>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<VaultApp />);
