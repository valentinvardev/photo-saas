/* atlas-portfolio-styles.jsx — CSS for the portfolio (injected once via React) */

const ATP_CSS = `
.atp-root{ font-family:var(--at-sans); }

/* ─── Top chrome ─── */
.atp-top{
  position:fixed; inset:0 auto auto 0; right:0; z-index:40;
  display:flex; align-items:center; justify-content:space-between;
  padding:14px 22px;
  background:var(--at-fg); color:var(--at-bg);
  border-bottom:1px solid var(--at-fg);
}
.atp-hamb{
  width:38px; height:38px; border:1px solid rgba(239,234,224,.35); border-radius:999px;
  background:transparent; color:var(--at-bg);
  display:flex; flex-direction:column; align-items:center; justify-content:center; gap:5px;
  cursor:pointer; transition:background .25s ease, border-color .25s ease;
}
.atp-hamb span{ display:block; width:14px; height:1px; background:currentColor; }
.atp-hamb:hover{ background:rgba(239,234,224,.1); border-color:rgba(239,234,224,.7); }
.atp-top-mark{ display:flex; align-items:center; }
.atp-top-mark .at-mark{ background:var(--at-bg); color:var(--at-fg); }

@media (max-width:700px){
  .atp-top{ padding:12px 16px; }
}

/* ─── Cover ─── */
.atp-cover{
  position:relative; min-height:100vh; min-height:100dvh; width:100%;
  display:grid; align-items:end; padding-top:64px;
  color:#fff; isolation:isolate;
}
.atp-cover-img{ position:absolute; inset:0; z-index:-1; background:#222; }
.atp-cover-img img{ width:100%; height:100%; object-fit:cover; }
.atp-cover-tint{
  position:absolute; inset:0;
  background:
    linear-gradient(180deg, rgba(0,0,0,.45) 0%, rgba(0,0,0,0) 30%, rgba(0,0,0,0) 60%, rgba(0,0,0,.6) 100%),
    linear-gradient(180deg, rgba(14,14,14,0) 50%, rgba(14,14,14,.35) 100%);
}
.atp-cover-grid{
  position:relative; z-index:1; display:grid;
  grid-template-rows: auto 1fr auto;
  grid-template-areas: "eye" "title" "foot";
  width:100%; padding: clamp(70px, 12vh, 110px) clamp(20px, 4vw, 56px) clamp(30px, 6vh, 56px);
  min-height:100vh; min-height:100dvh;
}
.atp-cover-eye{ grid-area:eye; }
.atp-cover-title{
  grid-area:title; align-self:end; margin:0;
  font-family:var(--at-display); font-weight:500; line-height:.92; letter-spacing:-0.045em;
  font-size: clamp(58px, 11vw, 180px);
  display:flex; flex-wrap:wrap; gap: 0 .25em;
}
.atp-cover-title > span:nth-child(1){ font-weight:500; }
.atp-cover-italic{ font-style:italic; font-weight:400; }
.atp-cover-num{
  font-feature-settings:"ss01" 1, "tnum" 1;
  font-style:italic; font-weight:300;
  border-bottom: 4px solid var(--at-accent); padding-bottom:.04em;
}
.atp-cover-foot{
  grid-area:foot; display:flex; align-items:end; justify-content:space-between; gap:24px; padding-top:24px;
  border-top:1px solid rgba(255,255,255,.18);
}
.atp-cover-cta{
  display:inline-flex; align-items:center; gap:14px; padding:8px 8px 8px 18px;
  border:1px solid rgba(255,255,255,.35); border-radius:999px; color:#fff;
  font-family:var(--at-mono); font-size:11px; letter-spacing:.1em; text-transform:uppercase;
  transition:background .25s ease, transform .25s var(--at-reveal);
}
.atp-cover-cta:hover{ background:rgba(255,255,255,.1); transform:translateY(-2px); }
.atp-cover-cta svg{ flex:none; }

@media (max-width:700px){
  .atp-cover-foot{ flex-direction:column; align-items:flex-start; }
}

/* ─── Section heads ─── */
.atp-section-head{
  display:grid; grid-template-columns: 200px 1fr; gap:32px; align-items:start;
  padding: clamp(80px, 12vh, 140px) clamp(20px, 4vw, 56px) clamp(40px, 6vh, 60px);
}
.atp-h2{
  margin:0; font-family:var(--at-display); font-weight:500; font-size:clamp(38px, 6vw, 84px);
  line-height:1.0; letter-spacing:-.04em;
}
.atp-h2 em{ font-style:italic; font-weight:400; }
@media (max-width:760px){ .atp-section-head{ grid-template-columns:1fr; gap:18px; } }

/* ─── Index list ─── */
.atp-index{ position:relative; padding-bottom: clamp(40px, 8vh, 100px); }
.atp-list{
  list-style:none; margin:0; padding:0 clamp(20px,4vw,56px);
  border-top:1px solid var(--at-line);
}
.atp-row{
  display:grid; grid-template-columns: 50px 1fr 140px 180px 80px 30px;
  gap:18px; align-items:center; padding: 26px 0; cursor:default;
  border-bottom:1px solid var(--at-line);
  transition:opacity .35s var(--at-reveal), padding .35s var(--at-reveal), color .25s ease;
}
.atp-row.is-dim{ opacity:.32; }
.atp-row.is-hover{ padding-left:14px; color:var(--at-fg); }
.atp-row-no{ font-family:var(--at-mono); font-size:11px; letter-spacing:.08em; color:var(--at-muted); }
.atp-row-title{
  font-family:var(--at-display); font-weight:500; font-size:clamp(34px, 4.6vw, 64px);
  letter-spacing:-.035em; line-height:1.0;
}
.atp-row-em em{ font-style:italic; font-weight:400; color:var(--at-muted); }
.atp-row-kind{ font-family:var(--at-mono); font-size:11px; letter-spacing:.08em; text-transform:uppercase; color:var(--at-muted); }
.atp-row-place{ font-family:var(--at-sans); font-size:14px; }
.atp-row-year{ font-family:var(--at-mono); font-size:13px; color:var(--at-muted); }
.atp-row-arrow{ font-size:18px; color:var(--at-muted); transition:transform .3s var(--at-reveal); }
.atp-row.is-hover .atp-row-arrow{ color:var(--at-accent); transform:translate(4px,-4px); }
@media (max-width:980px){
  .atp-row{ grid-template-columns: 40px 1fr 80px 30px; }
  .atp-row-place, .atp-row-year{ display:none; }
}
@media (max-width:560px){
  .atp-row{ grid-template-columns: 1fr 30px; row-gap:6px; padding:22px 0; }
  .atp-row-no{ grid-column:1 / 3; }
  .atp-row-kind{ grid-column:1 / 3; }
}

/* Cursor-follow preview */
.atp-cursor{
  position:absolute; left:0; top:0; pointer-events:none; z-index:5;
  width:280px; transition:transform .15s linear;
  margin-left:32px; margin-top:-30px;
}
.atp-cursor-img{ aspect-ratio: 4 / 5; border-radius:2px; box-shadow:0 30px 60px rgba(0,0,0,.18); }
.atp-cursor-meta{ display:flex; justify-content:space-between; align-items:baseline; padding-top:10px; color:var(--at-fg); }

/* Grid alt layout */
.atp-grid{
  display:grid; grid-template-columns: repeat(12, 1fr); gap:20px;
  padding:0 clamp(20px,4vw,56px);
}
.atp-card{ cursor:default; }
.atp-card:nth-child(1){ grid-column: span 7; }
.atp-card:nth-child(2){ grid-column: span 5; }
.atp-card:nth-child(3){ grid-column: span 4; }
.atp-card:nth-child(4){ grid-column: span 4; }
.atp-card:nth-child(5){ grid-column: span 4; }
.atp-card-img{ aspect-ratio: 4 / 5; }
.atp-card:nth-child(1) .atp-card-img{ aspect-ratio: 5 / 4; }
.atp-card-meta{ display:flex; flex-direction:column; gap:6px; padding-top:14px; }
.atp-card-title{ margin:0; font-family:var(--at-display); font-weight:500; font-size:clamp(22px, 2.4vw, 32px); letter-spacing:-.03em; }
.atp-card-place{ font-family:var(--at-mono); font-size:11px; letter-spacing:.08em; text-transform:uppercase; color:var(--at-muted); }
@media (max-width:760px){ .atp-grid > *{ grid-column: span 12 !important; } }

/* ─── Marquee ─── */
.atp-marquee{
  background:var(--at-fg); color:var(--at-bg);
  border-top:1px solid var(--at-fg); border-bottom:1px solid var(--at-fg);
  overflow:hidden; padding:18px 0;
}
.atp-marquee-track{
  display:flex; gap:48px; white-space:nowrap;
  animation: atp-marquee 38s linear infinite;
  font-family:var(--at-display); font-style:italic; font-size:clamp(28px, 5vw, 64px); letter-spacing:-.03em;
}
.atp-marquee-item{ display:inline-block; }
.atp-marquee-dot{ color:var(--at-accent); font-style:normal; }
@keyframes atp-marquee{ to { transform: translateX(-33.333%); } }

/* ─── About ─── */
.atp-about{ padding-bottom: clamp(60px, 8vh, 100px); }
.atp-about-grid{
  display:grid; grid-template-columns: 5fr 7fr; gap: clamp(28px,5vw,80px);
  padding: 0 clamp(20px,4vw,56px);
  align-items:start;
}
.atp-portrait{ margin:0; position:sticky; top:90px; }
.atp-about-copy p{ margin:0 0 22px; }
.atp-about-lede{ font-family:var(--at-display); font-weight:400; font-size:clamp(26px, 2.6vw, 38px); line-height:1.18; letter-spacing:-.02em; }
.atp-about-lede em{ font-style:italic; }
.atp-about-body{ font-family:var(--at-sans); font-size:17px; line-height:1.55; color:var(--at-muted); max-width:60ch; }
.atp-about-body em{ color:var(--at-fg); font-style:italic; font-family:var(--at-display); }

.atp-stats{
  list-style:none; padding:32px 0 0; margin:32px 0 0;
  border-top:1px solid var(--at-line);
  display:grid; grid-template-columns:repeat(4, 1fr); gap:18px;
}
.atp-stats li{ display:flex; flex-direction:column; gap:4px; }
.atp-stat-num{ font-family:var(--at-display); font-weight:500; font-size:clamp(34px, 4.4vw, 60px); letter-spacing:-.04em; line-height:1; }
.atp-stats .at-mono{ color:var(--at-muted); }

.atp-press{ margin-top:42px; padding-top:22px; border-top:1px solid var(--at-line); }
.atp-press-row{ display:flex; flex-wrap:wrap; gap:32px; align-items:center; margin-top:12px; color:var(--at-muted); }

@media (max-width:900px){
  .atp-about-grid{ grid-template-columns: 1fr; }
  .atp-portrait{ position:static; max-width:380px; }
  .atp-stats{ grid-template-columns:repeat(2,1fr); }
}

/* ─── Contact ─── */
.atp-contact{ padding: clamp(80px,10vh,120px) clamp(20px,4vw,56px) clamp(60px,8vh,100px); border-top:1px solid var(--at-line); }
.atp-contact-eye{ display:flex; gap:14px; color:var(--at-muted); margin-bottom:36px; }
.atp-contact-h{
  margin:0 0 56px; font-family:var(--at-display); font-weight:500;
  font-size:clamp(46px, 7vw, 110px); line-height:.95; letter-spacing:-.045em;
  display:flex; flex-wrap:wrap; gap: 0 .22em;
}
.atp-contact-grid{
  display:grid; grid-template-columns: 1fr 1fr; gap:0;
  border-top:1px solid var(--at-line);
}
.atp-contact-row{
  display:grid; grid-template-columns: 140px 1fr 30px;
  gap:24px; align-items:baseline; padding:28px 6px;
  border-bottom:1px solid var(--at-line); transition:padding .25s var(--at-reveal), color .2s ease;
}
.atp-contact-row:nth-child(odd){ border-right:1px solid var(--at-line); padding-right:30px; }
.atp-contact-row:hover{ padding-left:18px; color:var(--at-accent); }
.atp-contact-val{ font-family:var(--at-display); font-weight:500; font-size:clamp(22px, 2.4vw, 36px); letter-spacing:-.03em; }
.atp-contact-arrow{ font-size:18px; color:var(--at-muted); transition:transform .25s var(--at-reveal); }
.atp-contact-row:hover .atp-contact-arrow{ transform:translate(4px,-4px); color:var(--at-accent); }
@media (max-width:760px){
  .atp-contact-grid{ grid-template-columns:1fr; }
  .atp-contact-row:nth-child(odd){ border-right:0; padding-right:6px; }
}

/* ─── Footer ─── */
.atp-footer{ background:var(--at-fg); color:var(--at-bg); padding: clamp(60px, 10vh, 120px) clamp(20px,4vw,56px) 28px; }
.atp-footer-mark{ display:flex; flex-direction:column; align-items:flex-start; line-height:.85; padding-bottom:clamp(28px,5vh,60px); border-bottom:1px solid rgba(239,234,224,.18); }
.atp-footer-meta{ display:grid; grid-template-columns: 1fr 2fr; gap:24px; padding-top:36px; }
.atp-footer-cols{ display:grid; grid-template-columns: repeat(3,1fr); gap:24px; }
.atp-footer-cols ul{ list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:6px; font-size:14px; }
.atp-footer-cols ul li:first-child{ margin-bottom:6px; }
@media (max-width:760px){
  .atp-footer-meta{ grid-template-columns:1fr; }
  .atp-footer-cols{ grid-template-columns:repeat(2,1fr); }
}

/* ─── Slide-in nav ─── */
.atp-nav{ position:fixed; inset:0; z-index:90; pointer-events:none; }
.atp-nav.is-open{ pointer-events:auto; }
.atp-nav-bg{ position:absolute; inset:0; background:rgba(14,14,14,.5); opacity:0; transition:opacity .5s var(--at-curtain); }
.atp-nav.is-open .atp-nav-bg{ opacity:1; }
.atp-nav-panel{
  position:absolute; left:0; top:0; bottom:0; width:min(440px, 92vw);
  background:var(--at-bg); color:var(--at-fg); padding: 22px 28px;
  transform:translateX(-100%); transition:transform .55s var(--at-curtain);
  display:flex; flex-direction:column;
}
.atp-nav.is-open .atp-nav-panel{ transform:translateX(0); }
.atp-nav-head{ display:flex; align-items:center; gap:8px; padding-bottom:24px; border-bottom:1px solid var(--at-line); }
.atp-nav-x{ margin-left:auto; appearance:none; border:1px solid var(--at-line); background:transparent; width:34px; height:34px; border-radius:999px; cursor:pointer; }
.atp-nav-list{ list-style:none; margin:0; padding:24px 0; display:flex; flex-direction:column; gap:14px; }
.atp-nav-list li{ display:grid; grid-template-columns: 40px 1fr 24px; align-items:baseline; gap:12px; font-size:34px; line-height:1; letter-spacing:-.03em; cursor:default; }
.atp-nav-list li:hover{ color:var(--at-accent); }
.atp-nav-list li .at-mono{ color:var(--at-muted); }
.atp-nav-arrow{ font-size:18px; color:var(--at-muted); }
.atp-nav-sublist{ list-style:none; margin:14px 0 0; padding:0; display:flex; flex-direction:column; gap:10px; }
.atp-nav-sublist li{ display:grid; grid-template-columns:40px 1fr; gap:12px; font-family:var(--at-sans); font-size:18px; color:var(--at-muted); }
.atp-nav-foot{ margin-top:auto; padding-top:18px; border-top:1px solid var(--at-line); display:flex; justify-content:space-between; align-items:baseline; font-size:14px; }
`;

function AtpStyles(){
  return <style dangerouslySetInnerHTML={{ __html: ATP_CSS }} />;
}
window.AtpStyles = AtpStyles;
