/* atlas-portfolio.jsx — ATLAS portfolio page
   Sections: hamburger nav · cover · index (cursor-follow) · marquee · about · contact · footer */

const ATP_SERIF = "var(--at-display)";
const ATP_SANS  = "var(--at-sans)";
const ATP_MONO  = "var(--at-mono)";

function AtlasPortfolio({ density = "regular", layout = "index", onOpenProject }) {
  const [navOpen, setNavOpen] = React.useState(false);
  const [hovered, setHovered] = React.useState(null); // project id
  const [cursor, setCursor] = React.useState({ x: 0, y: 0 });
  const indexRef = React.useRef(null);

  // measure cursor relative to the index section for the floating preview
  function onMove(e) {
    if (!indexRef.current) return;
    const r = indexRef.current.getBoundingClientRect();
    setCursor({ x: e.clientX - r.left, y: e.clientY - r.top });
  }

  return (
    <div className="atp-root" style={{ background: "var(--at-bg)", color: "var(--at-fg)" }}>
      <AtpStyles />

      {/* fixed top chrome — hamburger + meta + clock */}
      <header className="atp-top">
        <button className="atp-hamb" aria-label="menu" onClick={() => setNavOpen(true)}>
          <span></span><span></span>
        </button>
        <div className="atp-top-mark">
          <span className="at-mark">a</span>
          <span style={{ fontFamily: ATP_MONO, fontSize: 11, letterSpacing: ".1em", textTransform: "uppercase", marginLeft: 10 }}>
            Atlas Studio<span style={{ opacity:.45, marginLeft:8 }}>est. 2018</span>
          </span>
        </div>
      </header>

      {/* Cover */}
      <section className="atp-cover" data-screen-label="01 Portfolio · Cover">
        <div className="atp-cover-img at-imgwrap">
          <img src={ATLAS_U("1469371670807-013ccf25f16a", 2200)} alt="" />
          <div className="atp-cover-tint" />
        </div>

        <div className="atp-cover-grid">
          <div className="atp-cover-eye">
            <span className="at-mono" style={{ color:"#fff", opacity:.65 }}>↳ Index 001 — 042</span>
          </div>
          <h1 className="atp-cover-title">
            <span>Photographer</span>
            <span className="atp-cover-italic">at large,</span>
            <span>since</span>
            <span className="atp-cover-num">2018</span>
          </h1>
          <div className="atp-cover-foot">
            <div>
              <div className="at-mono" style={{ color:"#fff", opacity:.55, marginBottom:6 }}>Selected work</div>
              <div style={{ fontFamily: ATP_SANS, color:"#fff", fontWeight:500, fontSize:15, letterSpacing:"-.01em" }}>
                Five years of weddings, editorial &amp; the in-between
              </div>
            </div>
            <a className="atp-cover-cta" href="#index">
              <span>Scroll for the work</span>
              <svg width="34" height="34" viewBox="0 0 34 34" fill="none"><circle cx="17" cy="17" r="16.5" stroke="currentColor" opacity=".5"/><path d="M13 15l4 4 4-4" stroke="currentColor" strokeWidth="1.4" fill="none"/></svg>
            </a>
          </div>
        </div>
      </section>

      {/* Index (cursor-follow image) */}
      <section
        id="index"
        ref={indexRef}
        className={`atp-index atp-index-${layout}`}
        onMouseMove={onMove}
        data-screen-label="02 Portfolio · Index"
      >
        <div className="atp-section-head">
          <span className="at-mono" style={{ color:"var(--at-muted)" }}>(02) Index</span>
          <h2 className="atp-h2">
            Five projects, <em>chosen</em>.<br/>
            The rest in <span style={{ color:"var(--at-accent)" }}>the archive ↗</span>
          </h2>
        </div>

        {layout === "index" && (
          <ul className="atp-list" onMouseLeave={() => setHovered(null)}>
            {ATLAS_PROJECTS.map((p, i) => (
              <li
                key={p.id}
                className={`atp-row ${hovered === p.id ? "is-hover" : ""} ${hovered && hovered !== p.id ? "is-dim" : ""}`}
                onMouseEnter={() => setHovered(p.id)}
                onClick={() => onOpenProject && onOpenProject(p.id)}
              >
                <span className="atp-row-no">{p.no}</span>
                <span className="atp-row-title">
                  {p.title}<span className="atp-row-em" style={{ fontFamily: ATP_SERIF }}>, <em>{p.subtitle.split(" ")[0].toLowerCase()}</em></span>
                </span>
                <span className="atp-row-kind">{p.kind}</span>
                <span className="atp-row-place">{p.place}</span>
                <span className="atp-row-year">{p.year}</span>
                <span className="atp-row-arrow">↗</span>
              </li>
            ))}
          </ul>
        )}

        {layout === "grid" && (
          <div className="atp-grid">
            {ATLAS_PROJECTS.map((p) => (
              <article key={p.id} className="atp-card" onClick={() => onOpenProject && onOpenProject(p.id)}>
                <div className="at-imgwrap atp-card-img">
                  <img src={ATLAS_U(p.cover, 1200)} alt="" />
                </div>
                <div className="atp-card-meta">
                  <span className="at-mono" style={{ color:"var(--at-muted)" }}>{p.no} / {p.kind}</span>
                  <h3 className="atp-card-title">{p.title}, <em style={{ fontFamily: ATP_SERIF }}>{p.year}</em></h3>
                  <span className="atp-card-place">{p.place}</span>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* cursor-follow preview, only for list layout */}
        {layout === "index" && hovered && (
          <AtpCursorPreview
            x={cursor.x}
            y={cursor.y}
            project={ATLAS_PROJECTS.find((p) => p.id === hovered)}
          />
        )}
      </section>

      {/* Marquee */}
      <AtpMarquee />

      {/* About */}
      <AtpAbout />

      {/* Contact */}
      <AtpContact />

      {/* Footer */}
      <AtpFooter />

      {/* Slide-in nav */}
      <AtpNav open={navOpen} onClose={() => setNavOpen(false)} />
    </div>
  );
}

window.AtlasPortfolio = AtlasPortfolio;
