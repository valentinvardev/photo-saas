/* vault-styles.jsx — CSS for VAULT */

const VT_CSS = `
.vt-root{ font-family:var(--vt-sans); color:var(--vt-fg); background:var(--vt-bg); padding-top:48px; }

/* TOP BAR */
.vt-top{
  position:fixed; top:0; left:0; right:0; height:48px; z-index:60;
  display:grid; grid-template-columns: 1fr 1fr 1fr; align-items:center;
  padding: 0 22px; background:var(--vt-bg); border-bottom:1px solid var(--vt-line);
}
.vt-top-l{ display:flex; align-items:baseline; gap:12px; }
.vt-top-c{ text-align:center; color:var(--vt-muted); }
.vt-top-c strong{ color:var(--vt-fg); margin:0 2px; }
.vt-top-r{ text-align:right; color:var(--vt-muted); }
@media (max-width:760px){
  .vt-top{ grid-template-columns: 1fr auto; height:44px; }
  .vt-top-c{ display:none; }
}

/* COVER */
.vt-cover{
  min-height: calc(100vh - 48px); padding: clamp(28px, 4vw, 56px);
  border-bottom:1px solid var(--vt-line);
  display:flex; flex-direction:column; justify-content:stretch;
}
.vt-cover-grid{
  flex:1; display:grid; grid-template-columns: 1.2fr 1fr; gap: clamp(28px,5vw,80px);
  align-items:stretch;
}
.vt-cover-l{ display:flex; flex-direction:column; justify-content:space-between; gap:32px; }
.vt-cover-eye{ color:var(--vt-muted); font-size:11px; line-height:1.6; max-width:30ch; }
.vt-cover-title{
  font-size: clamp(96px, 18vw, 320px); line-height:.85; letter-spacing:.005em;
  display:flex; flex-direction:column;
}
.vt-cover-amp{
  align-self:flex-start; font-family:var(--vt-display);
  font-size: clamp(60px, 9vw, 140px); color:var(--vt-accent);
  line-height:.7; margin: -.05em 0 -.05em .04em;
}
.vt-cover-meta{
  display:grid; grid-template-columns:repeat(5, 1fr); gap:24px;
  padding:24px 0; border-top:1px solid var(--vt-line); border-bottom:1px solid var(--vt-line);
}
.vt-cover-meta > div > div:first-child{ margin-bottom:6px; }
.vt-cover-cta{
  align-self:flex-start; display:inline-flex; align-items:center;
  padding:14px 24px; background:var(--vt-fg); color:var(--vt-bg);
  border-radius:0; transition:background .25s ease, gap .3s var(--vt-ease);
  cursor:pointer;
}
.vt-cover-cta:hover{ background:var(--vt-accent); }
.vt-cover-r{ display:flex; align-items:flex-end; }
.vt-cover-plate{ margin:0; width:100%; }
.vt-cover-plate figcaption{ padding-top:10px; color:var(--vt-fg); }
@media (max-width:900px){
  .vt-cover-grid{ grid-template-columns:1fr; }
  .vt-cover-meta{ grid-template-columns:repeat(3, 1fr); gap:18px; }
  .vt-cover-r{ order:-1; max-width:340px; }
}

/* INDEX / TOC */
.vt-toc{ padding: clamp(80px,12vh,140px) clamp(28px,4vw,56px); border-bottom:1px solid var(--vt-line); }
.vt-toc-head{ max-width:780px; margin: 0 auto clamp(40px,6vh,80px); text-align:center; display:flex; flex-direction:column; align-items:center; gap:18px; }
.vt-toc-head h2{ font-size: clamp(72px, 14vw, 200px); margin:0; line-height:.85; }
.vt-toc-head .vt-mono{ color:var(--vt-muted); }
.vt-toc-lede{ margin:0; max-width:46ch; font-size:18px; line-height:1.5; color:var(--vt-muted); }

.vt-toc-list{ list-style:none; margin: 0 auto; padding:0; max-width:1100px; display:flex; flex-direction:column; gap:36px; }
.vt-toc-cat{ display:flex; flex-direction:column; }
.vt-toc-cat-row{
  appearance:none; border:0; background:transparent; cursor:pointer; text-align:left;
  display:grid; grid-template-columns: 60px 1fr auto auto auto; gap:18px; align-items:baseline;
  padding:18px 4px; border-bottom:1px solid var(--vt-line);
  transition: padding .35s var(--vt-ease), color .25s ease;
}
.vt-toc-cat-row:hover{ padding-left:14px; color:var(--vt-accent); }
.vt-toc-no{ color:var(--vt-muted); font-size:13px; }
.vt-toc-name{ font-size: clamp(36px, 5vw, 64px); line-height:.95; }
.vt-toc-dots{
  flex:1; height:1px; align-self:center;
  background-image: radial-gradient(circle, var(--vt-line) 1px, transparent 1px);
  background-size: 8px 1px; background-repeat: repeat-x;
}
.vt-toc-meta{ color:var(--vt-muted); }
.vt-toc-sep{ margin:0 6px; opacity:.4; }
.vt-toc-page{ color:var(--vt-fg); padding-left:14px; border-left:1px solid var(--vt-line); margin-left:14px; }

.vt-toc-folders{
  list-style:none; margin: 8px 0 0 60px; padding:0;
  display:flex; flex-direction:column; gap:6px;
}
.vt-toc-folder{ color:var(--vt-muted); border-bottom:1px dotted var(--vt-line); }
.vt-toc-folder-btn{
  width:100%; appearance:none; border:0; background:transparent; cursor:pointer; text-align:left;
  display:grid; grid-template-columns: 70px 1fr 2fr auto; gap:14px; align-items:baseline;
  padding: 10px 4px; color:inherit;
  transition: padding .25s var(--vt-ease), color .2s ease;
}
.vt-toc-folder-btn:hover{ padding-left:14px; color:var(--vt-accent); }
.vt-toc-folder-btn:hover .vt-toc-fname{ color:var(--vt-accent); }
.vt-toc-fno{ color:var(--vt-accent); }
.vt-toc-fname{ font-family:var(--vt-display); font-size:22px; color:var(--vt-fg); letter-spacing:.005em; text-transform:uppercase; }
.vt-toc-fnote{ font-size:11px; }
.vt-toc-fcount{ color:var(--vt-fg); }

@media (max-width:760px){
  .vt-toc-cat-row{ grid-template-columns: 40px 1fr auto; }
  .vt-toc-dots, .vt-toc-meta{ display:none; }
  .vt-toc-folder{ grid-template-columns: 50px 1fr auto; }
  .vt-toc-folder .vt-toc-fnote{ display:none; }
}

/* CHAPTER */
.vt-chapter{ border-bottom:1px solid var(--vt-line); }

.vt-ch-cover{
  position:relative; height:min(80dvh, 760px); width:100%;
  overflow:hidden; isolation:isolate; color:#F0EADA;
  display:grid; align-items:end;
  padding: 0 clamp(28px,4vw,56px) clamp(36px,6vh,72px);
}
.vt-ch-cover-img{ position:absolute; inset:0; z-index:-1; background:#222; }
.vt-ch-cover-img img{ width:100%; height:100%; object-fit:cover; }
.vt-ch-cover-tint{
  position:absolute; inset:0;
  background: linear-gradient(180deg, rgba(0,0,0,.55) 0%, rgba(0,0,0,0) 35%, rgba(0,0,0,0) 60%, rgba(0,0,0,.7) 100%);
}
.vt-ch-cover-text{
  position:relative; z-index:1; max-width:740px;
  display:flex; flex-direction:column; gap:14px;
}
.vt-ch-name{
  margin:0; font-size:clamp(72px, 14vw, 220px); line-height:.85;
  color:#F0EADA;
}
.vt-ch-summary{ display:flex; flex-direction:column; max-width:50ch; }
.vt-ch-summary p{ margin:0; font-size:18px; line-height:1.5; color:rgba(244,240,230,.85); font-family:var(--vt-sans); font-weight:400; }
.vt-ch-foliage{
  position:absolute; right:clamp(28px,4vw,56px); top:clamp(24px,4vh,40px);
  font-size: clamp(120px, 22vw, 360px); line-height:.8; color:rgba(255,255,255,.18);
  pointer-events:none;
}

/* FOLDERS within chapter */
.vt-folders{ padding: clamp(48px,8vh,90px) 0; display:flex; flex-direction:column; gap: clamp(56px,9vh,100px); }
.vt-folder{ position:relative; }
.vt-folder-head{
  display:grid; grid-template-columns: 90px 1fr 1fr; gap:24px;
  padding: 0 clamp(28px,4vw,56px) 22px;
  align-items:end; border-bottom:1px solid var(--vt-line);
  margin-bottom:24px;
}
.vt-folder-no{ color:var(--vt-accent); }
.vt-folder-name{
  margin:0; font-size:clamp(40px, 6vw, 96px); line-height:.9;
}
.vt-folder-meta{ display:flex; flex-direction:column; gap:4px; align-items:flex-end; text-align:right; }
.vt-folder-note{
  grid-column: 2 / -1; max-width:62ch; margin:0;
  font-size:16px; line-height:1.55; color:var(--vt-muted); font-style:italic;
}

@media (max-width:760px){
  .vt-folder-head{ grid-template-columns: 50px 1fr; }
  .vt-folder-meta{ grid-column: 1 / -1; align-items:flex-start; text-align:left; flex-direction:row; gap:14px; }
  .vt-folder-note{ grid-column:1 / -1; }
}

/* RAIL — auto-glide carousel of plates */
.vt-rail{
  overflow:hidden; padding-bottom: 14px;
  -webkit-mask-image: linear-gradient(90deg, transparent 0, #000 4%, #000 96%, transparent 100%);
          mask-image: linear-gradient(90deg, transparent 0, #000 4%, #000 96%, transparent 100%);
}
.vt-rail-track{
  display:flex; align-items:flex-end; gap:14px; width:max-content;
  animation: vt-glide 60s linear infinite;
}
.vt-rail-track:hover{ animation-play-state: paused; }
@keyframes vt-glide{ to { transform: translateX(-50%); } }
.vt-plate{
  flex: 0 0 auto; width: clamp(220px, 26vw, 380px);
  margin:0; cursor:zoom-in; scroll-snap-align: start;
  display:flex; flex-direction:column; gap:8px;
}
.vt-plate-img{ aspect-ratio: 4 / 5; transition: transform .4s var(--vt-ease); }
.vt-plate.is-tall .vt-plate-img{ aspect-ratio: 3 / 5; }
.vt-plate.is-wide{ width: clamp(360px, 36vw, 520px); }
.vt-plate.is-wide .vt-plate-img{ aspect-ratio: 4 / 3; }
.vt-plate:hover .vt-plate-img{ transform: translateY(-4px); }
.vt-plate-cap{ display:flex; align-items:baseline; }

@media (prefers-reduced-motion: reduce){
  .vt-rail{ overflow-x:auto; }
  .vt-rail-track{ animation:none; width:auto; }
}

/* COLOPHON */
.vt-colophon{
  background:var(--vt-fg); color:var(--vt-bg);
  padding: clamp(80px,12vh,140px) clamp(28px,4vw,56px) 36px;
}
.vt-colophon-mark{ font-size:clamp(120px, 22vw, 320px); line-height:.85; padding-bottom: 36px; border-bottom:1px solid rgba(244,240,230,.15); margin-bottom: 36px; }
.vt-colophon-grid{ display:grid; grid-template-columns:repeat(4, 1fr); gap:24px; font-size:14px; }
.vt-colophon-grid > div > div:first-child{ margin-bottom:6px; }
@media (max-width:760px){ .vt-colophon-grid{ grid-template-columns:repeat(2,1fr); } }

/* LIGHTBOX */
.vt-lb{ position:fixed; inset:0; z-index:200; display:flex; flex-direction:column; }
.vt-lb-bg{ position:absolute; inset:0; background:rgba(14,12,10,.96); }
.vt-lb-head, .vt-lb-stage, .vt-lb-foot{ position:relative; z-index:1; color:#F0EADA; }
.vt-lb-head{ display:flex; justify-content:space-between; align-items:center; padding:18px 24px; border-bottom:1px solid rgba(244,240,230,.12); }
.vt-lb-x{ appearance:none; border:1px solid rgba(244,240,230,.18); background:transparent; color:inherit; width:34px; height:34px; cursor:pointer; }
.vt-lb-stage{ flex:1; display:flex; align-items:center; justify-content:center; padding:30px; min-height:0; }
.vt-lb-stage img{ max-width:100%; max-height:100%; object-fit:contain; }
.vt-lb-nav{ appearance:none; background:transparent; border:1px solid rgba(244,240,230,.18); color:inherit; width:48px; height:48px; cursor:pointer; position:absolute; top:50%; transform:translateY(-50%); font-family:var(--vt-display); font-size:22px; }
.vt-lb-nav:hover{ background:rgba(244,240,230,.08); }
.vt-lb-prev{ left:24px; }
.vt-lb-next{ right:24px; }
.vt-lb-foot{ padding:14px 24px; border-top:1px solid rgba(244,240,230,.12); color:rgba(244,240,230,.6); text-align:center; }
`;

function VtStyles(){
  return <style dangerouslySetInnerHTML={{ __html: VT_CSS }} />;
}
window.VtStyles = VtStyles;
