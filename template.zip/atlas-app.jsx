/* atlas-app.jsx — main shell wiring portfolio · delivery · links + Tweaks panel */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "page": "portfolio",
  "accent": "#2235FF",
  "theme": "cream",
  "portfolioLayout": "index",
  "deliveryLayout": "masonry",
  "density": "regular",
  "deliveryStage": "lock"
}/*EDITMODE-END*/;

const ATLAS_ACCENTS = [
  "#2235FF",  // electric cobalt
  "#0E0E0E",  // ink (monochrome)
  "#E8382C",  // vermilion
  "#1F8A5B",  // forest
];

const ATLAS_THEMES = {
  cream: { bg:"#EFEAE0", raised:"#E4DDCB", fg:"#0E0E0E", muted:"#6E6A60", line:"#D5CDB9" },
  ink:   { bg:"#0B0B0B", raised:"#141414", fg:"#EFEAE0", muted:"#8A8678", line:"#232323" },
  bone:  { bg:"#F5F2EC", raised:"#ECE7DD", fg:"#1A1916", muted:"#7A7468", line:"#DCD5C4" },
};

function AtlasApp(){
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply tokens to :root
  React.useEffect(()=>{
    const r = document.documentElement;
    const theme = ATLAS_THEMES[t.theme] || ATLAS_THEMES.cream;
    r.style.setProperty("--at-accent", t.accent);
    r.style.setProperty("--at-bg", theme.bg);
    r.style.setProperty("--at-raised", theme.raised);
    r.style.setProperty("--at-fg", theme.fg);
    r.style.setProperty("--at-muted", theme.muted);
    r.style.setProperty("--at-line", theme.line);
    r.dataset.theme = t.theme === "ink" ? "dark" : "light";
  },[t.accent, t.theme]);

  // Reset deliveryStage handling: when user picks a stage, force-rerender delivery
  const deliveryKey = `${t.deliveryStage}-${t.deliveryLayout}`;

  return (
    <div className="atlas-shell">
      {/* page switcher */}
      <nav className="atlas-pageswitch" aria-label="page switcher">
        {[
          ["portfolio", "Portfolio"],
          ["delivery",  "Delivery"],
          ["links",     "Links"],
        ].map(([k, l])=>(
          <button
            key={k}
            aria-current={t.page === k ? "true" : "false"}
            onClick={()=>setTweak("page", k)}
          >{l}</button>
        ))}
      </nav>

      {/* page mounts */}
      {t.page === "portfolio" && (
        <AtlasPortfolio
          density={t.density}
          layout={t.portfolioLayout}
        />
      )}
      {t.page === "delivery" && (
        <AtlasDelivery
          key={deliveryKey}
          density={t.density}
          layout={t.deliveryLayout}
          initialStage={t.deliveryStage}
        />
      )}
      {t.page === "links" && <AtlasLinks />}

      {/* Tweaks */}
      <TweaksPanel title="Atlas tweaks">
        <TweakSection label="View" />
        <TweakRadio
          label="Page"
          value={t.page}
          options={["portfolio", "delivery", "links"]}
          onChange={(v)=> setTweak("page", v)}
        />

        {t.page === "portfolio" && (
          <>
            <TweakSection label="Portfolio" />
            <TweakRadio
              label="Index layout"
              value={t.portfolioLayout}
              options={["index", "grid"]}
              onChange={(v)=>setTweak("portfolioLayout", v)}
            />
          </>
        )}

        {t.page === "delivery" && (
          <>
            <TweakSection label="Delivery" />
            <TweakRadio
              label="Stage"
              value={t.deliveryStage}
              options={["lock", "gallery"]}
              onChange={(v)=>setTweak("deliveryStage", v)}
            />
            <TweakRadio
              label="Photo grid"
              value={t.deliveryLayout}
              options={["masonry", "grid"]}
              onChange={(v)=>setTweak("deliveryLayout", v)}
            />
          </>
        )}

        <TweakSection label="Theme" />
        <TweakRadio
          label="Palette"
          value={t.theme}
          options={["cream", "bone", "ink"]}
          onChange={(v)=>setTweak("theme", v)}
        />
        <TweakColor
          label="Accent"
          value={t.accent}
          options={ATLAS_ACCENTS}
          onChange={(v)=>setTweak("accent", v)}
        />

        <TweakSection label="About" />
        <div style={{ fontSize:11, color:"rgba(41,38,27,.55)", lineHeight:1.5 }}>
          <strong style={{ color:"rgba(41,38,27,.85)" }}>ATLAS</strong> — sans-style template collection.<br/>
          Bricolage Grotesque · Geist · Geist Mono.<br/>
          Try the password <em>marais</em> on the lock gate.
        </div>
      </TweaksPanel>
    </div>
  );
}

/* Patch AtlasDelivery to accept an initial stage prop. We monkey-patch by wrapping. */
const _AtlasDelivery = window.AtlasDelivery;
window.AtlasDelivery = function AtlasDeliveryWrap(props){
  const Comp = _AtlasDelivery;
  // We use an internal initial-stage hack: render a ref that sets stage via the DOM.
  // Simpler: pass key from parent so component remounts with new initial state.
  return <_AtlasDeliveryStaged {...props} />;
};

function _AtlasDeliveryStaged(props){
  // Just call the original by inlining — but the original initial state is "lock".
  // To support starting at "gallery", we conditionally render a tiny wrapper that
  // posts a synthetic submit. Easiest path: re-implement by calling the original
  // component, then if initialStage === 'gallery' simulate the unlock by posting click.
  React.useEffect(()=>{
    if (props.initialStage === "gallery"){
      // submit the lock form on next tick
      requestAnimationFrame(()=>{
        const form = document.querySelector(".atd-lock-form");
        if (form){
          const ev = new Event("submit", { bubbles:true, cancelable:true });
          form.dispatchEvent(ev);
        }
      });
    }
  },[props.initialStage]);
  return <_AtlasDelivery {...props} />;
}

ReactDOM.createRoot(document.getElementById("root")).render(<AtlasApp />);
