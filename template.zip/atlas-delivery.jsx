/* atlas-delivery.jsx — ATLAS delivery page (lock + curtain + hero + chapters) */

function AtlasDelivery({ density = "regular", layout = "masonry" }){
  const [stage, setStage] = React.useState("lock"); // 'lock' | 'curtain' | 'gallery'
  const [pwd, setPwd] = React.useState("");
  const [shake, setShake] = React.useState(false);
  const [favs, setFavs] = React.useState(()=> new Set());
  const [filter, setFilter] = React.useState("all");
  const [scrolled, setScrolled] = React.useState(false);
  const [lightbox, setLightbox] = React.useState(null);
  const galleryRef = React.useRef(null);

  const D = ATLAS_DELIVERY;
  const allPhotos = React.useMemo(()=>{
    const flat = [];
    D.chapters.forEach(c => c.photos.forEach((id, i) => flat.push({ id: `${c.id}-${i}`, photoId: id, chapter: c.label })));
    return flat;
  },[]);

  function tryUnlock(e){
    e.preventDefault();
    if (pwd.trim().toLowerCase() === "marais" || pwd.trim() === ""){
      setStage("curtain");
      setTimeout(()=> setStage("gallery"), 600);
    } else {
      setShake(true); setTimeout(()=>setShake(false), 600);
    }
  }

  function toggleFav(id){
    setFavs(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  // scroll listener for sticky toolbar shadow
  React.useEffect(()=>{
    if (stage !== "gallery") return;
    const el = galleryRef.current;
    if (!el) return;
    const onScroll = () => setScrolled(el.scrollTop > window.innerHeight * 0.4);
    el.addEventListener("scroll", onScroll, { passive:true });
    return () => el.removeEventListener("scroll", onScroll);
  }, [stage]);

  const filteredCount = filter === "favs" ? favs.size : D.count;

  return (
    <div className="atd-root">
      <AtdStyles />

      {/* Top accent stripe */}
      <div className="atd-stripe" />

      {/* LOCK GATE */}
      {stage === "lock" && (
        <div className={`atd-lock ${shake ? "is-shake" : ""}`} data-screen-label="06 Delivery · Lock gate">
          <div className="atd-lock-bg">
            <img src={ATLAS_U(D.cover, 2000)} alt="" />
            <div className="atd-lock-bg-tint" />
          </div>

          <header className="atd-lock-top">
            <div className="atd-lock-mark">
              <span className="at-mark invert">a</span>
              <span style={{ marginLeft:10, fontFamily:"var(--at-mono)", fontSize:11, letterSpacing:".1em", textTransform:"uppercase" }}>
                Atlas Studio
              </span>
            </div>
            <div className="atd-lock-meta at-mono">
              private gallery · expires in 30 days
            </div>
          </header>

          <div className="atd-lock-card">
            <span className="at-mono atd-lock-eye">A delivery for —</span>
            <h1 className="atd-lock-title">
              <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontWeight:400 }}>Seraphine</span>
              <span style={{ opacity:.55 }}>&amp;</span>
              <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontWeight:400 }}>Theo</span>
            </h1>
            <div className="atd-lock-line at-mono">
              {D.date} <span className="atd-lock-dot">·</span> {D.location} <span className="atd-lock-dot">·</span> {D.count} photographs
            </div>

            <form className="atd-lock-form" onSubmit={tryUnlock}>
              <label className="at-mono" htmlFor="atd-pwd">Passphrase</label>
              <div className="atd-lock-input">
                <input
                  id="atd-pwd" type="text"
                  value={pwd}
                  onChange={e=>setPwd(e.target.value)}
                  placeholder="enter passphrase"
                  spellCheck="false"
                  autoComplete="off"
                />
                <button type="submit" className="atd-lock-go">
                  <span>Open</span>
                  <span className="atd-lock-arrow">→</span>
                </button>
              </div>
              <p className="atd-lock-hint at-mono">try: <em style={{fontFamily:"var(--at-display)"}}>marais</em></p>
            </form>
          </div>

          <footer className="atd-lock-foot at-mono">
            <span>built with <span style={{ color:"var(--at-accent)" }}>FRAME</span></span>
            <span>contact: hello@atlas.studio</span>
          </footer>
        </div>
      )}

      {/* CURTAIN */}
      {stage === "curtain" && <div className="atd-curtain" />}

      {/* GALLERY */}
      {stage === "gallery" && (
        <div className="atd-gallery" ref={galleryRef} data-screen-label="07 Delivery · Gallery">
          {/* HERO */}
          <header className="atd-hero">
            <div className="atd-hero-img at-imgwrap">
              <img src={ATLAS_U(D.cover, 2400)} alt="" />
              <div className="atd-hero-tint" />
            </div>
            <div className="atd-hero-mark">
              <span className="at-mark invert">a</span>
              <span style={{ marginLeft:10, fontFamily:"var(--at-mono)", fontSize:11, letterSpacing:".1em", textTransform:"uppercase", color:"#fff" }}>
                Atlas Studio
              </span>
            </div>
            <div className="atd-hero-block">
              <span className="at-mono" style={{ color:"rgba(255,255,255,.7)" }}>(your gallery)</span>
              <h1 className="atd-hero-title">
                <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontWeight:400 }}>Marais —</span>
                <span style={{ display:"block", fontFamily:"var(--at-display)", fontWeight:500 }}>A summer wedding.</span>
              </h1>
              <div className="atd-hero-meta at-mono">
                {D.date} <span style={{opacity:.5, margin:"0 10px"}}>·</span> {D.location} <span style={{opacity:.5, margin:"0 10px"}}>·</span> {D.count} photographs
              </div>
            </div>
          </header>

          {/* CTA strip */}
          <section className="atd-cta">
            <div>
              <span className="at-mono" style={{color:"var(--at-muted)"}}>(welcome)</span>
              <p className="atd-cta-lede">
                Seraphine, Theo — <em style={{fontFamily:"var(--at-display)"}}>here it is.</em>
                <br/>One hundred and forty-two from the day, organised in four chapters. Take your time. Favourite the ones you love; we'll work from there.
              </p>
            </div>
            <div className="atd-cta-actions">
              <button className="atd-btn atd-btn-primary">
                <span>Download all</span>
                <span style={{ opacity:.6, marginLeft:10 }}>2.1 GB · zip</span>
              </button>
              <button className="atd-btn atd-btn-ghost">Share with family</button>
            </div>
          </section>

          {/* Sticky toolbar */}
          <div className={`atd-toolbar ${scrolled ? "is-scrolled" : ""}`}>
            <div className="atd-pills">
              <button
                className={`atd-pill ${filter === "all" ? "is-active" : ""}`}
                onClick={()=>setFilter("all")}
              >All <span className="atd-pill-count">{D.count}</span></button>
              <button
                className={`atd-pill ${filter === "favs" ? "is-active" : ""}`}
                onClick={()=>setFilter("favs")}
              >
                <svg width="11" height="11" viewBox="0 0 24 24" style={{marginRight:6}}><path d="M12 21s-7-4.5-9-9 1-9 5-9 4 3 4 3 0-3 4-3 7 4 5 9-9 9-9 9z" fill="currentColor"/></svg>
                Favorites <span className="atd-pill-count">{favs.size}</span>
              </button>
            </div>
            <div className="atd-tools">
              <span className="at-mono atd-tools-meta">{filteredCount} shown</span>
              <button className="atd-tool-btn">Select all</button>
              <button className="atd-tool-btn atd-tool-primary">↓ Download selection</button>
            </div>
          </div>

          {/* Chapters */}
          {D.chapters.map((ch, ci) => {
            const visible = ch.photos
              .map((id, i) => ({ key: `${ch.id}-${i}`, photoId: id }))
              .filter(p => filter !== "favs" || favs.has(p.key));
            if (visible.length === 0 && filter === "favs") return null;
            return (
              <section key={ch.id} className="atd-chapter">
                <div className="atd-chapter-head">
                  <span className="at-mono atd-ch-no">{ch.no}</span>
                  <h2 className="atd-ch-title">{ch.label}</h2>
                  <span className="at-mono atd-ch-count">{ch.photos.length} photos</span>
                  <em className="atd-ch-note" style={{fontFamily:"var(--at-display)"}}>{ch.note}</em>
                </div>
                <div className={`atd-grid atd-grid-${layout}`}>
                  {visible.map((p, i) => {
                    const ratio = ATLAS_RATIOS[p.photoId] || 4/5;
                    const span = ratio < .9 ? "tall" : ratio > 1.4 ? "wide" : "sq";
                    return (
                      <figure
                        key={p.key}
                        className={`atd-cell atd-cell-${span} ${favs.has(p.key) ? "is-fav" : ""}`}
                        style={{ aspectRatio: layout === "grid" ? "4 / 5" : ratio }}
                        onClick={()=> setLightbox({ chapter: ch.label, key: p.key, photoId: p.photoId, idx: i, list: visible })}
                      >
                        <img src={ATLAS_U(p.photoId, 900)} alt="" loading="lazy" />
                        <div className="atd-cell-overlay">
                          <span className="at-mono atd-cell-no">{String(i+1).padStart(3,"0")}</span>
                          <button
                            className="atd-fav"
                            aria-label="favorite"
                            onClick={(e)=>{ e.stopPropagation(); toggleFav(p.key); }}
                          >
                            <svg width="16" height="16" viewBox="0 0 24 24"><path d="M12 21s-7-4.5-9-9 1-9 5-9 4 3 4 3 0-3 4-3 7 4 5 9-9 9-9 9z" fill={favs.has(p.key) ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.6"/></svg>
                          </button>
                        </div>
                      </figure>
                    );
                  })}
                </div>
              </section>
            );
          })}

          {/* Footer */}
          <footer className="atd-foot">
            <div className="atd-foot-mark" style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontSize:"clamp(60px, 13vw, 160px)", letterSpacing:"-.04em", lineHeight:.9 }}>
              thank you.
            </div>
            <div className="atd-foot-meta">
              <div>
                <div className="at-mono" style={{color:"var(--at-muted)"}}>delivered</div>
                <div>{D.date}</div>
              </div>
              <div>
                <div className="at-mono" style={{color:"var(--at-muted)"}}>expires</div>
                <div>July 14, 2025</div>
              </div>
              <div>
                <div className="at-mono" style={{color:"var(--at-muted)"}}>photographer</div>
                <div>Atlas Studio</div>
              </div>
              <div>
                <div className="at-mono" style={{color:"var(--at-muted)"}}>need help?</div>
                <div>hello@atlas.studio</div>
              </div>
            </div>
          </footer>

          {/* Mobile selection floater */}
          {favs.size > 0 && (
            <div className="atd-mobile-floater">
              <span><strong>{favs.size}</strong> selected</span>
              <button onClick={()=>setFavs(new Set())}>Clear</button>
              <button className="atd-btn atd-btn-primary atd-btn-sm">↓ Download</button>
            </div>
          )}
        </div>
      )}

      {/* Lightbox */}
      {lightbox && (
        <AtdLightbox
          item={lightbox}
          favs={favs}
          onToggleFav={toggleFav}
          onClose={()=>setLightbox(null)}
          onNext={()=>{
            const i = lightbox.list.findIndex(x=>x.key===lightbox.key);
            const next = lightbox.list[(i+1) % lightbox.list.length];
            setLightbox({ ...lightbox, key: next.key, photoId: next.photoId, idx:(i+1)%lightbox.list.length });
          }}
          onPrev={()=>{
            const i = lightbox.list.findIndex(x=>x.key===lightbox.key);
            const prev = lightbox.list[(i-1+lightbox.list.length)%lightbox.list.length];
            setLightbox({ ...lightbox, key: prev.key, photoId: prev.photoId, idx:(i-1+lightbox.list.length)%lightbox.list.length });
          }}
        />
      )}
    </div>
  );
}

function AtdLightbox({ item, favs, onToggleFav, onClose, onNext, onPrev }){
  React.useEffect(()=>{
    function onKey(e){
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowRight") onNext();
      else if (e.key === "ArrowLeft") onPrev();
      else if (e.key === "f" || e.key === "F") onToggleFav(item.key);
    }
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  },[item, onNext, onPrev, onClose, onToggleFav]);

  const isFav = favs.has(item.key);
  return (
    <div className="atd-lb" role="dialog" aria-modal="true">
      <div className="atd-lb-bg" onClick={onClose} />
      <div className="atd-lb-frame">
        <header className="atd-lb-head">
          <span className="at-mono">{String(item.idx+1).padStart(3,"0")} / {String(item.list.length).padStart(3,"0")} <span style={{opacity:.5, margin:"0 8px"}}>·</span> {item.chapter}</span>
          <div style={{ display:"flex", gap:8 }}>
            <button className="atd-lb-btn" onClick={()=>onToggleFav(item.key)}>
              <svg width="14" height="14" viewBox="0 0 24 24"><path d="M12 21s-7-4.5-9-9 1-9 5-9 4 3 4 3 0-3 4-3 7 4 5 9-9 9-9 9z" fill={isFav ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.6"/></svg>
              <span>{isFav ? "Favorited" : "Favorite"} <span style={{opacity:.5}}>· F</span></span>
            </button>
            <button className="atd-lb-btn">↓ <span>Download</span></button>
            <button className="atd-lb-btn atd-lb-x" onClick={onClose}>✕</button>
          </div>
        </header>
        <div className="atd-lb-stage">
          <button className="atd-lb-nav atd-lb-prev" onClick={onPrev} aria-label="previous">←</button>
          <img src={ATLAS_U(item.photoId, 1800)} alt="" />
          <button className="atd-lb-nav atd-lb-next" onClick={onNext} aria-label="next">→</button>
        </div>
      </div>
    </div>
  );
}

window.AtlasDelivery = AtlasDelivery;
window.AtdLightbox = AtdLightbox;
