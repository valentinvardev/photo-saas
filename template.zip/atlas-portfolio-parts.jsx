/* atlas-portfolio-parts.jsx — supporting components + CSS for portfolio */

function AtpClock(){
  const [t,setT] = React.useState(()=>new Date());
  React.useEffect(()=>{ const id=setInterval(()=>setT(new Date()),1000); return ()=>clearInterval(id); },[]);
  const hh = String(t.getUTCHours()).padStart(2,'0');
  const mm = String(t.getUTCMinutes()).padStart(2,'0');
  return <span><span style={{opacity:.55}}>UTC </span>{hh}:{mm}<span className="atp-blink">·</span></span>;
}

function AtpCursorPreview({ x, y, project }){
  if (!project) return null;
  return (
    <div className="atp-cursor" style={{ transform:`translate3d(${x}px, ${y}px, 0)` }}>
      <div className="at-imgwrap atp-cursor-img">
        <img src={ATLAS_U(project.cover, 900)} alt="" />
      </div>
      <div className="atp-cursor-meta">
        <span className="at-mono" style={{opacity:.55}}>{project.no} ↗</span>
        <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontSize:13 }}>{project.title}</span>
      </div>
    </div>
  );
}

function AtpMarquee(){
  const items = [
    "Atlas Studio","——","Available August through October","——",
    "Bookings open: weddings · editorial · brand","——","Now showing — Marais","——"
  ];
  return (
    <div className="atp-marquee" data-screen-label="03 Portfolio · Marquee">
      <div className="atp-marquee-track">
        {[...items, ...items, ...items].map((t,i)=>(
          <span key={i} className="atp-marquee-item">{t === "——" ? <span className="atp-marquee-dot">✺</span> : t}</span>
        ))}
      </div>
    </div>
  );
}

function AtpAbout(){
  return (
    <section className="atp-about" data-screen-label="04 Portfolio · About">
      <div className="atp-section-head">
        <span className="at-mono" style={{ color:"var(--at-muted)" }}>(04) Studio</span>
        <h2 className="atp-h2">
          A small studio<br/>
          <em style={{ fontFamily:"var(--at-display)" }}>making pictures</em> with care.
        </h2>
      </div>

      <div className="atp-about-grid">
        <figure className="atp-portrait">
          <div className="at-imgwrap" style={{ aspectRatio:"4 / 5" }}>
            <img src={ATLAS_U("1531746020798-e6953c6e8e04", 1100)} alt="Portrait of the photographer" />
          </div>
          <figcaption className="at-mono" style={{ color:"var(--at-muted)", marginTop:10 }}>
            Felix Marchand · Founder
          </figcaption>
        </figure>

        <div className="atp-about-copy">
          <p className="atp-about-lede">
            Atlas is a one-person studio working between <em style={{fontFamily:"var(--at-display)"}}>Paris and Lisbon</em>, photographing weddings, editorial portraits, and the occasional brand campaign.
          </p>
          <p className="atp-about-body">
            We work in small numbers. Eighteen weddings a year, four or five editorial commissions, and whatever else asks to be made. Each one gets a dedicated index — quiet, generous, organised the way we'd want to receive it ourselves.
          </p>
          <p className="atp-about-body">
            We are unapologetically slow about delivery, fast about replies, and entirely allergic to the words <em style={{fontFamily:"var(--at-display)"}}>capture, journey,</em> and <em style={{fontFamily:"var(--at-display)"}}>magical.</em>
          </p>

          <ul className="atp-stats">
            <li><span className="atp-stat-num">07</span><span className="at-mono">years</span></li>
            <li><span className="atp-stat-num">142</span><span className="at-mono">weddings</span></li>
            <li><span className="atp-stat-num">29</span><span className="at-mono">countries</span></li>
            <li><span className="atp-stat-num">06</span><span className="at-mono">awards</span></li>
          </ul>

          <div className="atp-press">
            <span className="at-mono" style={{ color:"var(--at-muted)" }}>As featured in</span>
            <div className="atp-press-row">
              <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontSize:22 }}>Vogue</span>
              <span style={{ fontFamily:"var(--at-display)", fontWeight:600, fontSize:18, letterSpacing:"-.04em" }}>Apartamento</span>
              <span style={{ fontFamily:"var(--at-mono)", fontSize:14, letterSpacing:".06em" }}>IGNANT</span>
              <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontSize:20 }}>Kinfolk</span>
              <span style={{ fontFamily:"var(--at-sans)", fontWeight:700, fontSize:16, letterSpacing:"-.02em" }}>It's Nice That</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AtpContact(){
  return (
    <section className="atp-contact" data-screen-label="05 Portfolio · Contact">
      <div className="atp-contact-eye">
        <span className="at-mono">(05) Make something</span>
      </div>
      <h2 className="atp-contact-h">
        <span>Tell us about</span>
        <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic" }}>the day,</span>
        <span>the place,</span>
        <span style={{ color:"var(--at-accent)" }}>the feeling.</span>
      </h2>

      <div className="atp-contact-grid">
        <a className="atp-contact-row" href="mailto:hello@atlas.studio">
          <span className="at-mono" style={{ color:"var(--at-muted)" }}>email</span>
          <span className="atp-contact-val">hello@atlas.studio</span>
          <span className="atp-contact-arrow">↗</span>
        </a>
        <a className="atp-contact-row" href="#">
          <span className="at-mono" style={{ color:"var(--at-muted)" }}>instagram</span>
          <span className="atp-contact-val">@atlas.studio</span>
          <span className="atp-contact-arrow">↗</span>
        </a>
        <a className="atp-contact-row" href="#">
          <span className="at-mono" style={{ color:"var(--at-muted)" }}>book a call</span>
          <span className="atp-contact-val">cal.com/atlas/intro</span>
          <span className="atp-contact-arrow">↗</span>
        </a>
        <a className="atp-contact-row" href="#">
          <span className="at-mono" style={{ color:"var(--at-muted)" }}>brief</span>
          <span className="atp-contact-val">Send a project brief</span>
          <span className="atp-contact-arrow">↗</span>
        </a>
      </div>
    </section>
  );
}

function AtpFooter(){
  return (
    <footer className="atp-footer">
      <div className="atp-footer-mark">
        <span style={{ fontFamily:"var(--at-display)", fontStyle:"italic", fontSize:"clamp(80px, 18vw, 240px)", letterSpacing:"-.04em", lineHeight:.9 }}>
          atlas
        </span>
        <span style={{ fontFamily:"var(--at-display)", fontWeight:500, fontSize:"clamp(80px, 18vw, 240px)", letterSpacing:"-.04em", lineHeight:.9 }}>
          studio.
        </span>
      </div>
      <div className="atp-footer-meta">
        <div>
          <div className="at-mono" style={{ color:"var(--at-muted)", marginBottom:6 }}>©2018—2026</div>
          <div>Atlas Studio · Paris / Lisbon</div>
        </div>
        <div className="atp-footer-cols">
          <ul>
            <li className="at-mono" style={{ color:"var(--at-muted)" }}>nav</li>
            <li>Index</li><li>Studio</li><li>Journal</li><li>Contact</li>
          </ul>
          <ul>
            <li className="at-mono" style={{ color:"var(--at-muted)" }}>elsewhere</li>
            <li>Instagram</li><li>Are.na</li><li>Substack</li>
          </ul>
          <ul>
            <li className="at-mono" style={{ color:"var(--at-muted)" }}>colophon</li>
            <li>Bricolage Grotesque</li><li>Geist</li><li>Built with FRAME</li>
          </ul>
        </div>
      </div>
    </footer>
  );
}

function AtpNav({ open, onClose }){
  return (
    <div className={`atp-nav ${open ? "is-open" : ""}`} aria-hidden={!open}>
      <div className="atp-nav-bg" onClick={onClose} />
      <aside className="atp-nav-panel">
        <header className="atp-nav-head">
          <span className="at-mark invert">a</span>
          <span className="at-mono" style={{ marginLeft:10 }}>Atlas Studio</span>
          <button className="atp-nav-x" onClick={onClose} aria-label="close">✕</button>
        </header>
        <ol className="atp-nav-list">
          {[
            ["00","Index"],["01","Marais"],["02","Rue Saint"],["03","Low Tide"],
            ["04","The Hours"],["05","Noctambule"]
          ].map(([n,t]) => (
            <li key={n}><span className="at-mono">{n}</span><span style={{fontFamily:"var(--at-display)"}}>{t}</span><span className="atp-nav-arrow">↗</span></li>
          ))}
        </ol>
        <hr className="at-hr" />
        <ol className="atp-nav-sublist">
          <li><span className="at-mono">06</span><span>Studio</span></li>
          <li><span className="at-mono">07</span><span>Contact</span></li>
          <li><span className="at-mono">08</span><span>Journal</span></li>
        </ol>
        <footer className="atp-nav-foot">
          <div className="at-mono" style={{ color:"var(--at-muted)" }}>open for</div>
          <div>Aug — Oct 2026</div>
        </footer>
      </aside>
    </div>
  );
}

window.AtpClock = AtpClock;
window.AtpCursorPreview = AtpCursorPreview;
window.AtpMarquee = AtpMarquee;
window.AtpAbout = AtpAbout;
window.AtpContact = AtpContact;
window.AtpFooter = AtpFooter;
window.AtpNav = AtpNav;
