/* vault-portfolio.jsx — VAULT portfolio: cover · index (TOC) · chapters · colophon */

function VaultPortfolio(){
  const D = VAULT_DATA;
  const [chapter, setChapter] = React.useState(null); // active chapter for top counter
  const [lightbox, setLightbox] = React.useState(null);
  const chaptersRef = React.useRef([]);

  // Track active chapter via IntersectionObserver
  React.useEffect(()=>{
    const els = chaptersRef.current.filter(Boolean);
    if (!els.length) return;
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{
        if (e.isIntersecting && e.intersectionRatio > 0.4){
          setChapter(e.target.dataset.chapterNo);
        }
      });
    },{ threshold: [0, .4, .8], rootMargin: "-30% 0px -30% 0px" });
    els.forEach(el=>io.observe(el));
    return ()=>io.disconnect();
  },[]);

  function scrollToCat(id){
    const el = document.getElementById(`vt-ch-${id}`);
    if (el) el.scrollIntoView({ behavior:"smooth", block:"start" });
  }

  function openLightbox(folder, idx){
    setLightbox({ folder, idx });
  }

  return (
    <div className="vt-root">
      <VtStyles />

      {/* Fixed top bar — runs the whole experience */}
      <header className="vt-top">
        <div className="vt-top-l">
          <span className="vt-disp" style={{fontSize:22}}>VAULT</span>
          <span className="vt-mono" style={{ marginLeft:12, color:"var(--vt-muted)" }}>{D.brand.edition}</span>
        </div>
        <div className="vt-top-c vt-mono">
          {chapter ? <>Chapter <strong style={{color:"var(--vt-fg)"}}>{chapter}</strong> of {String(D.totals.categories).padStart(2,"0")}</> : <>An archive</>}
        </div>
        <div className="vt-top-r vt-mono">
          {D.brand.photographer} <span style={{color:"var(--vt-muted)", margin:"0 8px"}}>·</span> {D.brand.based}
        </div>
      </header>

      {/* COVER — book-cover style */}
      <section className="vt-cover" data-screen-label="01 Cover">
        <div className="vt-cover-grid">
          <div className="vt-cover-l">
            <div className="vt-mono vt-cover-eye">
              An archive of pictures<br/>by {D.brand.photographer}.
            </div>
            <h1 className="vt-cover-title vt-disp">
              <span>VAULT</span>
              <span className="vt-cover-amp">&amp;</span>
              <span>INDEX</span>
            </h1>
            <div className="vt-cover-meta">
              <div>
                <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Edition</div>
                <div className="vt-disp" style={{fontSize:30}}>06</div>
              </div>
              <div>
                <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Year</div>
                <div className="vt-disp" style={{fontSize:30}}>2026</div>
              </div>
              <div>
                <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Categories</div>
                <div className="vt-disp" style={{fontSize:30}}>{String(D.totals.categories).padStart(2,"0")}</div>
              </div>
              <div>
                <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Folders</div>
                <div className="vt-disp" style={{fontSize:30}}>{String(D.totals.folders).padStart(2,"0")}</div>
              </div>
              <div>
                <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Photographs</div>
                <div className="vt-disp" style={{fontSize:30, color:"var(--vt-accent)"}}>{String(D.totals.photos).padStart(3,"0")}</div>
              </div>
            </div>

            <a href="#vt-toc" className="vt-cover-cta">
              <span className="vt-mono">Read the index</span>
              <span style={{fontFamily:"var(--vt-display)", fontSize:30, marginLeft:14}}>↓</span>
            </a>
          </div>

          <div className="vt-cover-r">
            <figure className="vt-cover-plate">
              <div className="vt-imgwrap" style={{ aspectRatio:"3 / 4" }}>
                <img src={VT_U(D.categories[0].cover, 1400)} alt="" />
              </div>
              <figcaption className="vt-mono">
                <span style={{color:"var(--vt-accent)"}}>Plate i</span> · {D.categories[0].folders[0].name}, {D.categories[0].folders[0].date}
              </figcaption>
            </figure>
          </div>
        </div>
      </section>

      {/* INDEX — Table of contents */}
      <section id="vt-toc" className="vt-toc" data-screen-label="02 Index">
        <header className="vt-toc-head">
          <span className="vt-mono">— Index —</span>
          <h2 className="vt-disp">CONTENTS</h2>
          <p className="vt-toc-lede">
            Four chapters, eleven folders, {D.totals.photos} photographs.<br/>
            Click any line to descend.
          </p>
        </header>

        <ol className="vt-toc-list">
          {D.categories.map((cat, ci) => (
            <li key={cat.id} className="vt-toc-cat">
              <button className="vt-toc-cat-row" onClick={()=>scrollToCat(cat.id)}>
                <span className="vt-mono vt-toc-no">{cat.no}</span>
                <span className="vt-toc-name vt-disp">{cat.name}</span>
                <span className="vt-toc-dots" aria-hidden="true"></span>
                <span className="vt-toc-meta vt-mono">
                  {cat.folders.length} folders <span className="vt-toc-sep">·</span> {cat.folders.reduce((a,f)=>a+f.photos.length,0)} photos <span className="vt-toc-sep">·</span> {cat.span}
                </span>
                <span className="vt-toc-page vt-mono">p. {String((ci+1)*16).padStart(3,"0")}</span>
              </button>

              <ul className="vt-toc-folders">
                {cat.folders.map(f => (
                  <li key={f.id} className="vt-toc-folder">
                    <button className="vt-toc-folder-btn" onClick={()=>{
                      const el = document.getElementById(`vt-fd-${f.id}`);
                      if (el) el.scrollIntoView({ behavior:"smooth", block:"start" });
                    }}>
                      <span className="vt-mono vt-toc-fno">{f.no}</span>
                      <span className="vt-toc-fname">{f.name}</span>
                      <span className="vt-toc-fnote vt-mono">{f.note}</span>
                      <span className="vt-toc-fcount vt-mono">{String(f.photos.length).padStart(2,"0")} pl. ↗</span>
                    </button>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ol>
      </section>

      {/* CHAPTERS */}
      {D.categories.map((cat, ci) => (
        <section
          key={cat.id}
          id={`vt-ch-${cat.id}`}
          ref={(el)=>{ chaptersRef.current[ci] = el; }}
          data-chapter-no={cat.no}
          data-screen-label={`${String(ci+3).padStart(2,"0")} Chapter · ${cat.name}`}
          className="vt-chapter"
        >
          {/* Chapter cover spread */}
          <div className="vt-ch-cover">
            <div className="vt-imgwrap vt-ch-cover-img">
              <img src={VT_U(cat.cover, 2000)} alt="" />
              <div className="vt-ch-cover-tint" />
            </div>
            <div className="vt-ch-cover-text">
              <div className="vt-mono" style={{ color:"rgba(244,240,230,.65)" }}>Chapter {cat.no} of {String(D.totals.categories).padStart(2,"0")}</div>
              <h2 className="vt-disp vt-ch-name">{cat.name}</h2>
              <div className="vt-ch-summary">
                <p>{cat.summary}</p>
                <div className="vt-mono" style={{ color:"rgba(244,240,230,.65)", marginTop:14 }}>
                  {cat.folders.length} folders · {cat.folders.reduce((a,f)=>a+f.photos.length,0)} photographs · {cat.span}
                </div>
              </div>
            </div>
            <div className="vt-ch-foliage vt-disp">{cat.no}</div>
          </div>

          {/* Folders within this chapter */}
          <div className="vt-folders">
            {cat.folders.map((f, fi) => (
              <article key={f.id} id={`vt-fd-${f.id}`} className="vt-folder">
                <header className="vt-folder-head">
                  <span className="vt-mono vt-folder-no">{f.no}</span>
                  <h3 className="vt-folder-name vt-disp">{f.name}</h3>
                  <div className="vt-folder-meta">
                    <span className="vt-mono">{f.place}</span>
                    <span className="vt-mono" style={{color:"var(--vt-muted)"}}>{f.date}</span>
                    <span className="vt-mono" style={{color:"var(--vt-muted)"}}>{String(f.photos.length).padStart(2,"0")} plates</span>
                  </div>
                  <p className="vt-folder-note">{f.note}</p>
                </header>

                {/* Auto-glide rail of plates */}
                <div className="vt-rail">
                  <div className="vt-rail-track" style={{ animationDuration: `${Math.max(28, f.photos.length * 5)}s` }}>
                    {[...f.photos, ...f.photos].map((pid, pi) => {
                      const real = pi % f.photos.length;
                      return (
                        <figure
                          key={pi}
                          className={`vt-plate ${real % 3 === 1 ? "is-tall" : real % 5 === 4 ? "is-wide" : ""}`}
                          onClick={()=>openLightbox(f, real)}
                          aria-hidden={pi >= f.photos.length ? "true" : "false"}
                        >
                          <div className="vt-imgwrap vt-plate-img">
                            <img src={VT_U(pid, 1100)} alt="" loading="lazy" />
                          </div>
                          <figcaption className="vt-mono vt-plate-cap">
                            <span style={{color:"var(--vt-accent)"}}>{f.no}.{String(real+1).padStart(2,"0")}</span>
                            <span style={{color:"var(--vt-muted)", marginLeft:10}}>plate {String(real+1).padStart(2,"0")} of {String(f.photos.length).padStart(2,"0")}</span>
                          </figcaption>
                        </figure>
                      );
                    })}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
      ))}

      {/* COLOPHON */}
      <footer className="vt-colophon" data-screen-label="Colophon">
        <div className="vt-colophon-mark vt-disp">VAULT</div>
        <div className="vt-colophon-grid">
          <div>
            <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Photographer</div>
            <div>{D.brand.photographer}</div>
            <div className="vt-mono" style={{ color:"var(--vt-muted)", marginTop:6 }}>{D.brand.based}</div>
          </div>
          <div>
            <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Edition</div>
            <div>{D.brand.edition}</div>
            <div className="vt-mono" style={{ color:"var(--vt-muted)", marginTop:6 }}>Set in Anton, Manrope &amp; JetBrains Mono.</div>
          </div>
          <div>
            <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Contact</div>
            <div>hello@vault.studio</div>
            <div className="vt-mono" style={{ color:"var(--vt-muted)", marginTop:6 }}>For commissions &amp; the archive.</div>
          </div>
          <div>
            <div className="vt-mono" style={{color:"var(--vt-muted)"}}>Built with</div>
            <div style={{color:"var(--vt-accent)"}}>FRAME</div>
            <div className="vt-mono" style={{ color:"var(--vt-muted)", marginTop:6 }}>©2018 — 2026</div>
          </div>
        </div>
      </footer>

      {lightbox && (
        <VtLightbox
          folder={lightbox.folder}
          idx={lightbox.idx}
          onClose={()=>setLightbox(null)}
          onNext={()=>setLightbox(s=>({ ...s, idx:(s.idx+1)%s.folder.photos.length }))}
          onPrev={()=>setLightbox(s=>({ ...s, idx:(s.idx-1+s.folder.photos.length)%s.folder.photos.length }))}
        />
      )}
    </div>
  );
}

function VtLightbox({ folder, idx, onClose, onNext, onPrev }){
  React.useEffect(()=>{
    function onKey(e){
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowRight") onNext();
      else if (e.key === "ArrowLeft") onPrev();
    }
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  },[onClose, onNext, onPrev]);

  return (
    <div className="vt-lb">
      <div className="vt-lb-bg" onClick={onClose} />
      <header className="vt-lb-head">
        <span className="vt-mono">
          <span style={{color:"var(--vt-accent)"}}>{folder.no}.{String(idx+1).padStart(2,"0")}</span>
          <span style={{margin:"0 10px", opacity:.5}}>·</span>
          {folder.name} · {folder.place}
        </span>
        <button className="vt-lb-x" onClick={onClose}>✕</button>
      </header>
      <div className="vt-lb-stage">
        <button className="vt-lb-nav vt-lb-prev" onClick={onPrev}>←</button>
        <img src={VT_U(folder.photos[idx], 1800)} alt="" />
        <button className="vt-lb-nav vt-lb-next" onClick={onNext}>→</button>
      </div>
      <footer className="vt-lb-foot vt-mono">
        plate {String(idx+1).padStart(2,"0")} of {String(folder.photos.length).padStart(2,"0")}
      </footer>
    </div>
  );
}

window.VaultPortfolio = VaultPortfolio;
window.VtLightbox = VtLightbox;
