/* atlas-delivery-styles.jsx — CSS for delivery page */

const ATD_CSS = `
.atd-root{ font-family:var(--at-sans); color:var(--at-fg); background:var(--at-bg); }

/* top accent stripe */
.atd-stripe{ position:fixed; top:0; left:0; right:0; height:3px; background:var(--at-accent); z-index:60; }

/* ─── LOCK GATE ─── */
.atd-lock{
  position:relative; min-height:100vh; min-height:100dvh; width:100%;
  display:grid; grid-template-rows: auto 1fr auto; align-items:stretch;
  color:#EFEAE0; isolation:isolate;
  padding: 22px clamp(20px,4vw,56px);
}
.atd-lock.is-shake{ animation: atd-shake .55s var(--at-curtain); }
@keyframes atd-shake{
  10%,90%{transform:translateX(-2px)}
  20%,80%{transform:translateX(4px)}
  30%,50%,70%{transform:translateX(-8px)}
  40%,60%{transform:translateX(8px)}
}
.atd-lock-bg{ position:absolute; inset:0; z-index:-1; overflow:hidden; }
.atd-lock-bg img{ width:100%; height:100%; object-fit:cover; filter: saturate(.85) contrast(1.02); }
.atd-lock-bg-tint{
  position:absolute; inset:0;
  background: radial-gradient(120% 80% at 50% 50%, rgba(0,0,0,.2), rgba(0,0,0,.7));
}

.atd-lock-top{ display:flex; justify-content:space-between; align-items:center; }
.atd-lock-mark{ display:flex; align-items:center; }
.atd-lock-meta{ color:rgba(239,234,224,.7); font-size:11px; }

.atd-lock-card{
  align-self:center; justify-self:center; width:min(560px, 92vw); text-align:center;
  display:flex; flex-direction:column; gap:14px; padding:48px 32px;
  background:rgba(14,14,14,.5);
  backdrop-filter:blur(28px) saturate(140%); -webkit-backdrop-filter:blur(28px) saturate(140%);
  border:.5px solid rgba(255,255,255,.18); border-radius:0;
}
.atd-lock-eye{ color:rgba(239,234,224,.6); margin-bottom:6px; }
.atd-lock-title{
  margin:0; font-size: clamp(48px, 7vw, 88px); line-height:.95; letter-spacing:-.04em;
  display:flex; gap:.18em; justify-content:center; flex-wrap:wrap;
}
.atd-lock-line{ color:rgba(239,234,224,.85); font-size:11px; margin-top:2px; }
.atd-lock-dot{ color:var(--at-accent); margin:0 8px; }

.atd-lock-form{ display:flex; flex-direction:column; gap:8px; margin-top:24px; align-items:stretch; text-align:left; }
.atd-lock-form > label{ color:rgba(239,234,224,.6); }
.atd-lock-input{
  display:flex; align-items:stretch;
  border:1px solid rgba(239,234,224,.3); border-radius:0;
  background:rgba(0,0,0,.25);
}
.atd-lock-input input{
  flex:1; appearance:none; background:transparent; border:0; padding:18px 20px;
  color:#EFEAE0; font-family:var(--at-display); font-size:22px; letter-spacing:-.01em;
  outline:none;
}
.atd-lock-input input::placeholder{ color:rgba(239,234,224,.4); font-style:italic; }
.atd-lock-go{
  appearance:none; border:0; padding:0 24px; background:var(--at-accent); color:#fff;
  font-family:var(--at-mono); font-size:11px; letter-spacing:.1em; text-transform:uppercase;
  display:flex; align-items:center; gap:10px; cursor:pointer; transition:background .25s ease, gap .25s ease;
}
.atd-lock-go:hover{ background:#0E22DD; gap:14px; }
.atd-lock-arrow{ font-family:var(--at-display); font-size:18px; }
.atd-lock-hint{ color:rgba(239,234,224,.4); margin:8px 0 0; }

.atd-lock-foot{ display:flex; justify-content:space-between; color:rgba(239,234,224,.5); font-size:10px; }

@media (max-width:520px){
  .atd-lock-card{ padding:32px 22px; }
}

/* ─── CURTAIN ─── */
.atd-curtain{
  position:fixed; inset:0; z-index:120;
  background:var(--at-accent);
  animation: atd-curtain 1.1s var(--at-curtain) forwards;
  transform-origin:left center;
}
@keyframes atd-curtain{
  0%{ clip-path: inset(0 100% 0 0); }
  45%{ clip-path: inset(0 0 0 0); }
  100%{ clip-path: inset(0 0 0 100%); }
}

/* ─── GALLERY ─── */
.atd-gallery{
  position:relative; min-height:100vh;
  animation: atd-fade .8s var(--at-reveal) .3s both;
}
@keyframes atd-fade{ from{opacity:0;transform:translateY(10px)} to{opacity:1; transform:none} }

/* HERO */
.atd-hero{
  position:relative; height: min(70dvh, 720px); width:100%;
  overflow:hidden; isolation:isolate; color:#fff;
}
.atd-hero-img{ position:absolute; inset:0; z-index:-1; }
.atd-hero-img img{ width:100%; height:100%; object-fit:cover; }
.atd-hero-tint{
  position:absolute; inset:0;
  background:
    linear-gradient(180deg, rgba(0,0,0,.4) 0%, rgba(0,0,0,0) 30%, rgba(0,0,0,0) 60%, rgba(0,0,0,.55) 100%);
}
.atd-hero-mark{ position:absolute; top:22px; left:clamp(20px,4vw,56px); display:flex; align-items:center; }
.atd-hero-block{
  position:absolute; left:clamp(20px,4vw,56px); bottom:clamp(28px,5vh,56px); right:clamp(20px,4vw,56px);
  display:flex; flex-direction:column; gap:18px;
}
.atd-hero-title{
  margin:0;
  font-family:var(--at-display);
  font-size:clamp(48px, 8vw, 128px); line-height:.92; letter-spacing:-.045em;
}
.atd-hero-meta{ color:rgba(255,255,255,.85); font-size:11px; }

/* CTA strip */
.atd-cta{
  display:grid; grid-template-columns: 1fr auto; gap:32px; align-items:end;
  padding: clamp(40px,6vh,72px) clamp(20px,4vw,56px);
  border-bottom:1px solid var(--at-line);
}
.atd-cta-lede{
  margin:14px 0 0; font-family:var(--at-display); font-weight:400;
  font-size:clamp(22px, 2.6vw, 32px); line-height:1.25; letter-spacing:-.02em;
  max-width:60ch;
}
.atd-cta-actions{ display:flex; gap:10px; flex-wrap:wrap; }
.atd-btn{
  appearance:none; border:0; cursor:pointer;
  font-family:var(--at-mono); font-size:11px; letter-spacing:.1em; text-transform:uppercase;
  padding:18px 22px; transition:transform .25s var(--at-reveal), background .25s ease, color .25s ease;
}
.atd-btn-primary{ background:var(--at-fg); color:var(--at-bg); }
.atd-btn-primary:hover{ background:var(--at-accent); color:#fff; }
.atd-btn-ghost{ background:transparent; color:var(--at-fg); border:1px solid var(--at-line); }
.atd-btn-ghost:hover{ border-color:var(--at-fg); }
.atd-btn-sm{ padding:10px 14px; font-size:10px; }

@media (max-width:760px){
  .atd-cta{ grid-template-columns:1fr; }
}

/* TOOLBAR */
.atd-toolbar{
  position:sticky; top:3px; z-index:30;
  display:flex; justify-content:space-between; align-items:center; gap:18px;
  padding: 14px clamp(20px,4vw,56px);
  background:var(--at-bg); border-bottom:1px solid transparent;
  transition: box-shadow .3s ease, border-color .3s ease;
}
.atd-toolbar.is-scrolled{
  border-color:var(--at-line);
  box-shadow:0 8px 30px rgba(14,14,14,.05);
}
.atd-pills{ display:flex; gap:6px; padding:4px; background:var(--at-raised); border-radius:999px; }
.atd-pill{
  appearance:none; border:0; background:transparent; cursor:pointer;
  display:inline-flex; align-items:center; gap:6px;
  padding:8px 14px; border-radius:999px;
  font-family:var(--at-mono); font-size:11px; letter-spacing:.08em; text-transform:uppercase;
  color:var(--at-muted); transition:background .25s ease, color .25s ease;
}
.atd-pill.is-active{ background:var(--at-fg); color:var(--at-bg); }
.atd-pill-count{ opacity:.65; margin-left:4px; }

.atd-tools{ display:flex; align-items:center; gap:14px; }
.atd-tools-meta{ color:var(--at-muted); }
.atd-tool-btn{
  appearance:none; border:0; background:transparent; cursor:pointer;
  font-family:var(--at-mono); font-size:11px; letter-spacing:.08em; text-transform:uppercase;
  color:var(--at-fg); padding:8px 12px; border-radius:999px;
  transition:background .25s ease;
}
.atd-tool-btn:hover{ background:var(--at-raised); }
.atd-tool-primary{ background:var(--at-accent); color:#fff; }
.atd-tool-primary:hover{ background:#0E22DD; color:#fff; }

@media (max-width:760px){
  .atd-tools .atd-tool-btn:not(.atd-tool-primary){ display:none; }
}

/* CHAPTER */
.atd-chapter{ padding: clamp(40px,6vh,80px) clamp(20px,4vw,56px); }
.atd-chapter-head{
  display:grid; grid-template-columns: auto auto 1fr auto;
  align-items:end; gap:24px; padding-bottom:24px; margin-bottom:24px;
  border-bottom:1px solid var(--at-line);
}
.atd-ch-no{ color:var(--at-accent); }
.atd-ch-title{ margin:0; font-family:var(--at-display); font-weight:500; font-size:clamp(36px, 5vw, 72px); letter-spacing:-.04em; line-height:1; }
.atd-ch-count{ color:var(--at-muted); }
.atd-ch-note{
  grid-column: 1 / -1; max-width:60ch; color:var(--at-muted);
  font-size:clamp(16px,1.6vw,18px); margin-top:4px;
}
@media (max-width:760px){
  .atd-chapter-head{ grid-template-columns: auto 1fr; }
  .atd-ch-count{ grid-column: 1 / -1; }
}

/* GRID layouts */
.atd-grid{ display:grid; gap: 14px; }
.atd-grid-grid{ grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); }
.atd-grid-masonry{
  /* CSS columns masonry */
  column-count: 4; column-gap: 14px; display:block;
}
.atd-grid-masonry .atd-cell{
  width:100%; break-inside:avoid; margin-bottom:14px;
  aspect-ratio: auto !important; display:block;
}
@media (max-width:1100px){ .atd-grid-masonry{ column-count:3; } }
@media (max-width:720px){ .atd-grid-masonry{ column-count:2; } }
@media (max-width:420px){ .atd-grid-masonry{ column-count:1; } }

.atd-cell{
  position:relative; overflow:hidden; cursor:zoom-in; background:var(--at-raised);
  margin:0; transition: transform .35s var(--at-reveal);
}
.atd-cell img{ width:100%; height:100%; object-fit:cover; display:block; transition:transform .8s var(--at-reveal); }
.atd-grid-masonry .atd-cell img{ height:auto; }
.atd-cell:hover img{ transform:scale(1.02); }
.atd-cell-overlay{
  position:absolute; inset:0; padding:10px;
  display:flex; justify-content:space-between; align-items:flex-start;
  pointer-events:none; opacity:0; transition: opacity .25s ease;
  background: linear-gradient(180deg, rgba(0,0,0,.35), rgba(0,0,0,0) 40%, rgba(0,0,0,0) 60%, rgba(0,0,0,.45));
  color:#fff;
}
.atd-cell:hover .atd-cell-overlay,
.atd-cell.is-fav .atd-cell-overlay{ opacity:1; }
.atd-cell-no{ font-size:10px; letter-spacing:.08em; opacity:.85; }
.atd-fav{
  appearance:none; border:0; background:rgba(0,0,0,.4); color:#fff;
  width:30px; height:30px; border-radius:999px; cursor:pointer;
  display:inline-flex; align-items:center; justify-content:center; pointer-events:auto;
  transition: background .2s ease, color .2s ease;
}
.atd-fav:hover{ background:rgba(0,0,0,.6); }
.atd-cell.is-fav .atd-fav{ background:var(--at-accent); color:#fff; }
.atd-cell.is-fav { box-shadow: inset 0 0 0 2px var(--at-accent); }

/* FOOTER */
.atd-foot{
  background:var(--at-fg); color:var(--at-bg);
  padding: clamp(60px,10vh,120px) clamp(20px,4vw,56px) 28px;
}
.atd-foot-mark{ padding-bottom:36px; border-bottom:1px solid rgba(239,234,224,.18); }
.atd-foot-meta{
  display:grid; grid-template-columns:repeat(4,1fr); gap:24px;
  padding-top:36px; font-size:14px;
}
.atd-foot-meta > div > div:first-child{ margin-bottom:6px; }
@media (max-width:760px){ .atd-foot-meta{ grid-template-columns:repeat(2,1fr); } }

/* MOBILE FLOATER */
.atd-mobile-floater{
  position:fixed; left:14px; right:14px; bottom: calc(14px + env(safe-area-inset-bottom));
  z-index:50; display:none; align-items:center; gap:14px;
  padding:12px 14px; background:var(--at-fg); color:var(--at-bg); border-radius:999px;
  font-family:var(--at-mono); font-size:11px; letter-spacing:.08em; text-transform:uppercase;
  box-shadow:0 12px 30px rgba(0,0,0,.25);
}
.atd-mobile-floater button{ appearance:none; border:0; background:transparent; color:inherit; cursor:pointer; padding:6px 10px; }
.atd-mobile-floater .atd-btn{ margin-left:auto; }
@media (max-width:760px){ .atd-mobile-floater{ display:flex; } }

/* LIGHTBOX */
.atd-lb{ position:fixed; inset:0; z-index:200; display:flex; align-items:center; justify-content:center; }
.atd-lb-bg{ position:absolute; inset:0; background:rgba(11,11,11,.96); animation: atd-fade-in .25s ease; }
@keyframes atd-fade-in{ from{opacity:0} to{opacity:1} }
.atd-lb-frame{ position:relative; z-index:1; width:100%; height:100%; display:flex; flex-direction:column; color:#EFEAE0; }
.atd-lb-head{ display:flex; justify-content:space-between; align-items:center; padding:18px 24px; border-bottom:1px solid rgba(239,234,224,.12); font-family:var(--at-mono); font-size:11px; letter-spacing:.08em; text-transform:uppercase; }
.atd-lb-btn{
  display:inline-flex; align-items:center; gap:8px;
  appearance:none; border:1px solid rgba(239,234,224,.18); background:transparent; color:inherit;
  padding:8px 14px; cursor:pointer; transition:background .2s ease;
  font-family:var(--at-mono); font-size:10px; letter-spacing:.08em; text-transform:uppercase;
}
.atd-lb-btn:hover{ background:rgba(239,234,224,.08); }
.atd-lb-x{ width:36px; padding:0; justify-content:center; }
.atd-lb-stage{
  flex:1; position:relative; display:flex; align-items:center; justify-content:center; padding:40px;
  min-height:0;
}
.atd-lb-stage img{ max-width:100%; max-height:100%; object-fit:contain; }
.atd-lb-nav{
  appearance:none; background:transparent; border:1px solid rgba(239,234,224,.18); color:inherit;
  width:48px; height:48px; border-radius:999px; cursor:pointer;
  position:absolute; top:50%; transform:translateY(-50%);
  font-family:var(--at-display); font-size:22px;
  transition:background .2s ease;
}
.atd-lb-nav:hover{ background:rgba(239,234,224,.08); }
.atd-lb-prev{ left:24px; }
.atd-lb-next{ right:24px; }
`;

function AtdStyles(){
  return <style dangerouslySetInnerHTML={{ __html: ATD_CSS }} />;
}
window.AtdStyles = AtdStyles;
